
function on_click()
    go_to_scene("level_01")
end