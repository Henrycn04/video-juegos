
scenes = {
    [0] =
    {name = "main_menu", path = "./assets/scripts/scene_menu.lua"},
    {name = "level_01", path = "./assets/scripts/scene_01.lua"},
    
}